# embed_and_build.py
import base64
import os
import sys
import subprocess
import shutil

def embed_client_into_builder():
    """Read Client.py, embed it as base64 in builder script, then build the builder"""
    
    print("=" * 60)
    print("   EMBEDDING Client.py INTO BUILDER")
    print("=" * 60)
    print()
    
    # Check if files exist
    if not os.path.exists("Client.py"):
        print("ERROR: Client.py not found in current directory!")
        print(f"Current directory: {os.getcwd()}")
        return False
    
    if not os.path.exists("build_installer_gui.py"):
        print("ERROR: build_installer_gui.py not found!")
        print("Make sure you have the builder script.")
        return False
    
    print("✓ Found Client.py")
    print("✓ Found build_installer_gui.py")
    print()
    
    # Read Client.py content
    print("Reading Client.py...")
    try:
        with open("Client.py", 'r', encoding='utf-8') as f:
            client_content = f.read()
        
        # Encode to base64
        client_b64 = base64.b64encode(client_content.encode('utf-8')).decode('utf-8')
        print(f"✓ Client.py encoded to base64 ({len(client_b64)} chars)")
    except Exception as e:
        print(f"✗ Failed to read Client.py: {e}")
        return False
    
    # Read builder template
    print("\nReading builder template...")
    try:
        with open("build_installer_gui.py", 'r', encoding='utf-8') as f:
            builder_template = f.read()
        
        # Replace placeholder with actual base64
        if "[CLIENT_PY_BASE64_CONTENT]" in builder_template:
            builder_content = builder_template.replace(
                "[CLIENT_PY_BASE64_CONTENT]", 
                client_b64
            )
            print("✓ Replaced placeholder with Client.py content")
        else:
            print("✗ Placeholder not found in builder template")
            print("Make sure build_installer_gui.py contains: [CLIENT_PY_BASE64_CONTENT]")
            return False
    except Exception as e:
        print(f"✗ Failed to read builder template: {e}")
        return False
    
    # Save embedded builder
    embedded_builder = "build_installer_gui_embedded.py"
    print(f"\nSaving embedded builder as: {embedded_builder}")
    try:
        with open(embedded_builder, 'w', encoding='utf-8') as f:
            f.write(builder_content)
        print(f"✓ Embedded builder saved")
    except Exception as e:
        print(f"✗ Failed to save embedded builder: {e}")
        return False
    
    # Build the embedded builder into executable
    print("\n" + "=" * 60)
    print("   BUILDING STANDALONE BUILDER EXECUTABLE")
    print("=" * 60)
    print()
    
    # Create PyInstaller command
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed",
        "--name=ChatClientBuilder",
        "--clean",
        "--noupx",
        # Add Client.py as data file (backup method)
        "--add-data=Client.py;.",
        # Hidden imports
        "--hidden-import=tkinter",
        "--hidden-import=customtkinter",
        "--hidden-import=PIL",
        "--hidden-import=PIL._tkinter_finder",
        "--hidden-import=base64",
        "--hidden-import=json",
        "--hidden-import=subprocess",
        "--hidden-import=threading",
        "--hidden-import=shutil",
        "--hidden-import=os",
        "--hidden-import=sys",
        "--hidden-import=time",
        "--hidden-import=traceback",
        "--hidden-import=pathlib",
        "--hidden-import=tempfile",
        "--collect-all=customtkinter",
        "--collect-all=PIL",
        embedded_builder
    ]
    
    print(f"Running PyInstaller...")
    print(f"Command: {' '.join(cmd[:5])} ... [truncated]")
    print()
    
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        print("Build progress:")
        print("-" * 40)
        
        for line in iter(process.stdout.readline, ''):
            if line.strip():
                # Show important messages
                if "WARNING" in line or "ERROR" in line:
                    print(f"  {line.strip()}")
                elif "writing" in line.lower() or "building" in line.lower():
                    print(f"  {line.strip()}")
                elif "completed" in line.lower():
                    print(f"  {line.strip()}")
        
        process.stdout.close()
        return_code = process.wait()
        
        if return_code == 0:
            print("-" * 40)
            print("✓ Builder executable created successfully!")
            
            # Check if executable was created
            exe_path = os.path.join("dist", "ChatClientBuilder.exe")
            if os.path.exists(exe_path):
                size_mb = os.path.getsize(exe_path) / (1024 * 1024)
                print(f"✓ Executable: {exe_path}")
                print(f"✓ Size: {size_mb:.2f} MB")
                
                # Create launcher
                create_final_launcher()
                
                # Clean up
                if os.path.exists(embedded_builder):
                    os.remove(embedded_builder)
                    print(f"✓ Cleaned up temporary file: {embedded_builder}")
                
                return True
            else:
                print("✗ Executable not found at expected location")
                return False
        else:
            print(f"\n✗ Build failed with return code {return_code}")
            return False
            
    except Exception as e:
        print(f"\n✗ Error during build: {str(e)}")
        return False

def create_final_launcher():
    """Create a launcher for the standalone builder"""
    launcher_content = '''@echo off
title STANDALONE CHAT CLIENT BUILDER
color 0A

echo ============================================
echo   STANDALONE CHAT CLIENT BUILDER
echo ============================================
echo.
echo This is a standalone builder that includes:
echo   • Complete GUI interface
echo   • Client.py EMBEDDED inside the executable
echo   • No external files needed!
echo.
echo Features:
echo   • Build ChatClient.exe with one click
echo   • No Python installation required
echo   • No Client.py file needed separately
echo   • Everything is self-contained
echo.
echo ============================================
echo.

REM Check if builder exists
if not exist "dist\\ChatClientBuilder.exe" (
    echo ERROR: Builder executable not found!
    echo.
    echo Please run embed_and_build.py first to create the builder.
    echo.
    pause
    exit /b 1
)

echo Starting Standalone Chat Client Builder...
echo.
echo Note: The builder will extract Client.py from its embedded resources
echo and use it to build your chat client executable.
echo.
timeout /t 3 /nobreak >nul

REM Run the builder
start "" "dist\\ChatClientBuilder.exe"

echo.
echo Builder started successfully!
echo Check your taskbar for the application window.
echo.
pause
'''
    
    with open("Run_Standalone_Builder.bat", "w") as f:
        f.write(launcher_content)
    
    print("✓ Launcher created: Run_Standalone_Builder.bat")
    
    # Create README
    readme_content = """STANDALONE CHAT CLIENT BUILDER
===============================

WHAT IS THIS?
-------------
This is a completely standalone executable that can build the Chat Client
without needing any external files. It contains:

1. The builder GUI interface
2. Client.py EMBEDDED inside the executable
3. All Python dependencies packaged

NO EXTERNAL FILES NEEDED!
- No need to have Client.py separately
- No need to install Python
- No need to install dependencies
- Everything is self-contained

HOW TO USE:
-----------
1. Double-click "Run_Standalone_Builder.bat"
2. OR run "dist\ChatClientBuilder.exe" directly
3. Click "Build Chat Client" in the GUI
4. Your ChatClient.exe will be created in the "dist" folder

WHAT HAPPENS WHEN YOU RUN IT:
-----------------------------
1. The builder extracts Client.py from its embedded resources
2. Creates a Python virtual environment (first time only)
3. Installs required packages (first time only)
4. Uses PyInstaller to build ChatClient.exe
5. Places the executable in the "dist" folder

TROUBLESHOOTING:
----------------
If the builder fails:
1. Run as Administrator
2. Check antivirus/firewall settings
3. Ensure you have internet connection (for first-time package downloads)
4. Make sure you have write permissions in the current directory

NOTE: The first build takes longer as it downloads and installs packages.
Subsequent builds will be much faster.
"""
    
    with open("README_Standalone.txt", "w") as f:
        f.write(readme_content)
    
    print("✓ Documentation created: README_Standalone.txt")

def main():
    print("\nThis script will:")
    print("1. Read your Client.py file")
    print("2. Embed it into the builder script as base64")
    print("3. Build a standalone executable that contains everything")
    print("4. Create a launcher and documentation")
    print()
    print("RESULT: A single EXE file that can build the chat client")
    print("        without needing Client.py separately!")
    print()
    
    response = input("Proceed? (y/n): ").lower()
    if response not in ['y', 'yes']:
        print("Operation cancelled.")
        return
    
    print("\n" + "=" * 60)
    
    if embed_client_into_builder():
        print("\n" + "=" * 60)
        print("SUCCESS: Standalone builder created!")
        print("=" * 60)
        print("\nYou now have:")
        print("1. dist\\ChatClientBuilder.exe - Standalone builder")
        print("2. Run_Standalone_Builder.bat - Launcher script")
        print("3. README_Standalone.txt - Documentation")
        print()
        print("The builder contains Client.py embedded inside it!")
        print("Users don't need Client.py separately.")
        print()
        print("To use: Double-click Run_Standalone_Builder.bat")
    else:
        print("\n" + "=" * 60)
        print("PROCESS FAILED!")
        print("=" * 60)
        print("\nCheck the error messages above.")
        print("Common issues:")
        print("1. Files not in current directory")
        print("2. PyInstaller not installed (pip install pyinstaller)")
        print("3. Insufficient disk space")
        print("4. Permission issues")
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
