# build_installer_gui.py
import subprocess
import sys
import os
import json
import tempfile
import shutil
from pathlib import Path
import tkinter as tk
import webbrowser
from tkinter import scrolledtext, ttk, messagebox
import threading
import time

class InstallerBuilderGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Chat Client Installer Builder")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        
        # Set icon if available
        try:
            self.root.iconbitmap('icon.ico')
        except:
            pass
            
        self.setup_ui()
        self.build_process = None
        self.is_building = False
        
    def setup_ui(self):
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        
        # Header frame
        header_frame = tk.Frame(self.root, bg="#2c3e50", height=80)
        header_frame.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        header_frame.columnconfigure(0, weight=1)
        header_frame.grid_propagate(False)
        
        title = tk.Label(
            header_frame,
            text="Chat Client Installer Builder",
            font=("Arial", 20, "bold"),
            fg="white",
            bg="#2c3e50"
        )
        title.grid(row=0, column=0, padx=20, pady=20)
        
        # Main content frame
        main_frame = tk.Frame(self.root)
        main_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(0, weight=1)
        
        # Configuration panel
        config_frame = ttk.LabelFrame(main_frame, text="Build Configuration", padding=10)
        config_frame.grid(row=0, column=0, sticky="ew", padx=5, pady=(0, 10))
        config_frame.columnconfigure(1, weight=1)
        
        # Output name
        ttk.Label(config_frame, text="Output Name:").grid(row=0, column=0, sticky="w", pady=5)
        self.output_name = tk.StringVar(value="ChatClient")
        ttk.Entry(config_frame, textvariable=self.output_name, width=30).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        
        # Git repository to clone
        ttk.Label(config_frame, text="Git Repo URL:").grid(row=2, column=0, sticky="w", pady=5)
        self.repo_url = tk.StringVar(value="https://github.com/yuri1659/do_an1.git")
        ttk.Entry(config_frame, textvariable=self.repo_url, width=60).grid(row=2, column=1, sticky="ew", padx=5, pady=5)

        ttk.Label(config_frame, text="Git Branch:").grid(row=3, column=0, sticky="w", pady=5)
        self.repo_branch = tk.StringVar(value="update")
        ttk.Entry(config_frame, textvariable=self.repo_branch, width=30).grid(row=3, column=1, sticky="w", padx=5, pady=5)

        ttk.Label(config_frame, text="Destination Folder:").grid(row=4, column=0, sticky="w", pady=5)
        self.repo_dest = tk.StringVar(value="external_repos/do_an1")
        ttk.Entry(config_frame, textvariable=self.repo_dest, width=60).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        
        # Icon file
        ttk.Label(config_frame, text="Icon File (.ico):").grid(row=1, column=0, sticky="w", pady=5)
        icon_frame = tk.Frame(config_frame)
        icon_frame.grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        icon_frame.columnconfigure(0, weight=1)
        
        self.icon_path = tk.StringVar()
        ttk.Entry(icon_frame, textvariable=self.icon_path).grid(row=0, column=0, sticky="ew")
        ttk.Button(icon_frame, text="Browse", command=self.browse_icon, width=10).grid(row=0, column=1, padx=(5, 0))
        
        # Build options
        options_frame = ttk.LabelFrame(main_frame, text="Build Options", padding=10)
        options_frame.grid(row=1, column=0, sticky="ew", padx=5, pady=(0, 10))
        
        self.create_single_exe = tk.BooleanVar(value=True)
        self.create_shortcut = tk.BooleanVar(value=True)
        self.include_upx = tk.BooleanVar(value=False)
        self.clean_build = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(options_frame, text="Create Single Executable (--onefile)", 
                       variable=self.create_single_exe).grid(row=0, column=0, sticky="w", pady=2)
        ttk.Checkbutton(options_frame, text="Create Desktop Shortcut", 
                       variable=self.create_shortcut).grid(row=1, column=0, sticky="w", pady=2)
        ttk.Checkbutton(options_frame, text="Use UPX Compression", 
                       variable=self.include_upx).grid(row=0, column=1, sticky="w", pady=2, padx=20)
        ttk.Checkbutton(options_frame, text="Clean Build Directory", 
                       variable=self.clean_build).grid(row=1, column=1, sticky="w", pady=2, padx=20)
        
        # Log output area
        log_frame = ttk.LabelFrame(main_frame, text="Build Log", padding=5)
        log_frame.grid(row=2, column=0, sticky="nsew", padx=5, pady=(0, 10))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            wrap=tk.WORD,
            width=80,
            height=20,
            font=("Consolas", 10)
        )
        self.log_text.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        
        # Configure tags for different log levels
        self.log_text.tag_config("INFO", foreground="black")
        self.log_text.tag_config("SUCCESS", foreground="green", font=("Consolas", 10, "bold"))
        self.log_text.tag_config("ERROR", foreground="red", font=("Consolas", 10, "bold"))
        self.log_text.tag_config("WARNING", foreground="orange")
        self.log_text.tag_config("COMMAND", foreground="blue")
        
        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.grid(row=3, column=0, sticky="ew", padx=5, pady=(0, 10))
        
        # Button frame
        button_frame = tk.Frame(main_frame)
        button_frame.grid(row=4, column=0, pady=10)
        
        self.build_btn = ttk.Button(
            button_frame,
            text="Build Installer",
            command=self.start_build,
            width=20
        )
        self.build_btn.pack(side=tk.LEFT, padx=5)
        
        self.cancel_btn = ttk.Button(
            button_frame,
            text="Cancel",
            command=self.cancel_build,
            state=tk.DISABLED,
            width=20
        )
        self.cancel_btn.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Open Output Folder",
            command=self.open_output_folder,
            width=20
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Exit",
            command=self.root.quit,
            width=20
        ).pack(side=tk.LEFT, padx=5)
        
    def browse_icon(self):
        filetypes = [("Icon files", "*.ico"), ("All files", "*.*")]
        filename = tk.filedialog.askopenfilename(
            title="Select Icon File",
            filetypes=filetypes
        )
        if filename:
            self.icon_path.set(filename)
            
    def log(self, message, level="INFO"):
        self.log_text.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {message}\n", level)
        self.log_text.see(tk.END)
        self.root.update_idletasks()
        
    def start_build(self):
        if self.is_building:
            return
            
        self.is_building = True
        self.build_btn.config(state=tk.DISABLED)
        self.cancel_btn.config(state=tk.NORMAL)
        self.progress.start()
        
        # Clear log
        self.log_text.delete(1.0, tk.END)
        self.log("Starting build process...", "INFO")
        
        # Start build in separate thread
        build_thread = threading.Thread(target=self.run_build)
        build_thread.daemon = True
        build_thread.start()
        
    def cancel_build(self):
        if self.build_process:
            self.build_process.terminate()
            self.log("Build cancelled by user.", "WARNING")
        self.finish_build(False)
        
    def run_build(self):
        try:
            # Create virtual environment
            self.log("Creating Python virtual environment...", "INFO")
            venv_path = "build_env"
            
            if os.path.exists(venv_path):
                shutil.rmtree(venv_path)
                
            subprocess.run([sys.executable, "-m", "venv", venv_path], 
                          check=True, capture_output=True, text=True)
            self.log("Virtual environment created successfully.", "SUCCESS")
            
            # Determine pip path based on OS
            if os.name == 'nt':
                pip_path = os.path.join(venv_path, "Scripts", "pip.exe")
                python_path = os.path.join(venv_path, "Scripts", "python.exe")
            else:
                pip_path = os.path.join(venv_path, "bin", "pip")
                python_path = os.path.join(venv_path, "bin", "python")
            
            # Install dependencies
            self.log("Installing dependencies...", "INFO")
            packages = ["customtkinter", "pycryptodome", "pyinstaller"]
            
            for package in packages:
                self.log(f"Installing {package}...", "INFO")
                result = subprocess.run(
                    [pip_path, "install", package],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0:
                    self.log(f"Successfully installed {package}", "SUCCESS")
                else:
                    self.log(f"Failed to install {package}: {result.stderr}", "ERROR")
                    self.finish_build(False)
                    return

            # Clone specified git repo and install its requirements (if provided)
            repo_url = self.repo_url.get().strip()
            repo_branch = self.repo_branch.get().strip()
            repo_dest = self.repo_dest.get().strip()

            if repo_url:
                if not self.ensure_git_available():
                    self.log("Git not found. Attempting to install or guide user...", "WARNING")
                    if not self.try_install_git():
                        self.log("Git installation/availability failed. Please install git and try again.", "ERROR")
                        self.finish_build(False)
                        return

                try:
                    self.clone_and_install_repo(repo_url, repo_branch or None, repo_dest, pip_path)
                except Exception as e:
                    self.log(f"Failed to clone/install repo: {str(e)}", "ERROR")
                    self.finish_build(False)
                    return
            
            # Build PyInstaller command
            output_name = self.output_name.get()
            icon_path = self.icon_path.get()
            
            cmd = [
                python_path, "-m", "PyInstaller",
                "--name", output_name,
                "--windowed",
                "--clean" if self.clean_build.get() else "",
            ]
            
            if self.create_single_exe.get():
                cmd.append("--onefile")
            else:
                cmd.append("--onedir")
                
            if icon_path and os.path.exists(icon_path):
                cmd.extend(["--icon", icon_path])
                
            if not self.include_upx.get():
                cmd.append("--noupx")
                
            # Add hidden imports
            hidden_imports = [
                "Crypto",
                "Crypto.Cipher",
                "Crypto.Cipher._raw_cbc",
                "Crypto.Util",
                "customtkinter",
                "queue",
                "tkinter"
            ]
            
            for imp in hidden_imports:
                cmd.extend(["--hidden-import", imp])
                
            # Add main script
            cmd.append("Client.py")
            
            # Filter out empty strings
            cmd = [arg for arg in cmd if arg]
            
            self.log(f"Running command: {' '.join(cmd)}", "COMMAND")
            
            # Run PyInstaller
            self.build_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            # Read output in real-time
            for line in iter(self.build_process.stdout.readline, ''):
                if line.strip():
                    self.log(line.strip(), "INFO")
                    
            self.build_process.stdout.close()
            return_code = self.build_process.wait()
            
            if return_code == 0:
                self.log("PyInstaller build completed successfully!", "SUCCESS")
                
                # Create shortcut if requested
                if self.create_shortcut.get() and os.name == 'nt':
                    self.create_desktop_shortcut(output_name)
                    
                # Show success message
                self.finish_build(True)
            else:
                self.log(f"PyInstaller failed with code {return_code}", "ERROR")
                self.finish_build(False)
                
        except Exception as e:
            self.log(f"Build error: {str(e)}", "ERROR")
            self.finish_build(False)
            
    def create_desktop_shortcut(self, app_name):
        try:
            # Create shortcut using Windows Script Host
            import win32com.client
            
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            shortcut_path = os.path.join(desktop, f"{app_name}.lnk")
            
            target_path = os.path.join(os.getcwd(), "dist", f"{app_name}.exe")
            
            shell = win32com.client.Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = target_path
            shortcut.WorkingDirectory = os.path.dirname(target_path)
            shortcut.Description = "Chat Client Application"
            
            if self.icon_path.get() and os.path.exists(self.icon_path.get()):
                shortcut.IconLocation = self.icon_path.get()
                
            shortcut.save()
            self.log(f"Desktop shortcut created: {shortcut_path}", "SUCCESS")
            
        except ImportError:
            # If win32com is not available, create a batch file as fallback
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            batch_path = os.path.join(desktop, f"{app_name}.bat")
            target_path = os.path.join(os.getcwd(), "dist", f"{app_name}.exe")
            
            with open(batch_path, 'w') as f:
                f.write(f'@echo off\n"{target_path}" %*\npause')
                
            self.log(f"Batch file shortcut created: {batch_path}", "WARNING")
            
        except Exception as e:
            self.log(f"Failed to create shortcut: {str(e)}", "WARNING")

    def ensure_git_available(self):
        git_path = shutil.which('git')
        if git_path:
            self.log(f"Found git at: {git_path}", "INFO")
            return True
        else:
            return False

    def try_install_git(self):
        """Best-effort attempt to install Git or guide the user to install it.

        Returns True if git becomes available, False otherwise.
        """
        # If git already available, we're done
        if shutil.which('git'):
            return True

        self.log("Git not detected on system. Attempting automatic install where possible.", "INFO")

        # Windows: open download page and ask user to install
        if os.name == 'nt':
            if messagebox.askyesno("Install Git", "Git is required. Open download page for Git for Windows now?"):
                webbrowser.open("https://git-scm.com/download/win")
            return False

        # macOS: try Homebrew if available
        if sys.platform == 'darwin':
            if shutil.which('brew'):
                self.log("Attempting to install git via Homebrew...", "INFO")
                result = subprocess.run(['brew', 'install', 'git'], capture_output=True, text=True)
                if result.returncode == 0:
                    self.log("Git installed successfully via Homebrew.", "SUCCESS")
                    return True
                else:
                    self.log(f"Homebrew install failed: {result.stderr}", "WARNING")
            if messagebox.askyesno("Install Git", "Automatic install failed. Open Git download page in browser?"):
                webbrowser.open("https://git-scm.com/download/mac")
            return False

        # Assume Linux/Unix
        # Try common package managers: apt-get, dnf, yum, pacman
        pkg_managers = [
            ('apt-get', [['sudo', 'apt-get', 'update'], ['sudo', 'apt-get', 'install', '-y', 'git']]),
            ('dnf', [['sudo', 'dnf', 'install', '-y', 'git']]),
            ('yum', [['sudo', 'yum', 'install', '-y', 'git']]),
            ('pacman', [['sudo', 'pacman', '-Sy', '--noconfirm', 'git']]),
        ]

        for name, commands in pkg_managers:
            if shutil.which(name):
                for cmd in commands:
                    self.log(f"Running: {' '.join(cmd)}", "INFO")
                    try:
                        result = subprocess.run(cmd, capture_output=True, text=True)
                    except Exception as e:
                        self.log(f"Failed to run {cmd}: {e}", "WARNING")
                        result = None

                    if result is not None and result.returncode != 0:
                        self.log(f"Command {' '.join(cmd)} failed: {result.stderr}", "WARNING")

                # After attempting installation, check for git again
                if shutil.which('git'):
                    self.log("Git installed and now available on PATH.", "SUCCESS")
                    return True
                else:
                    self.log(f"Git still not found after trying {name}.", "WARNING")

        # If we reach here, automatic install failed or no known package manager found
        if messagebox.askyesno("Install Git", "Automatic installation failed or requires manual steps. Open Git download page in browser?"):
            webbrowser.open("https://git-scm.com/download/")

        return False

    def clone_and_install_repo(self, repo_url, branch, dest_dir, pip_path):
        # Normalize destination
        dest_dir = os.path.abspath(dest_dir)
        parent = os.path.dirname(dest_dir)
        if parent and not os.path.exists(parent):
            os.makedirs(parent, exist_ok=True)

        if not os.path.exists(dest_dir):
            self.log(f"Cloning {repo_url} (branch: {branch}) into {dest_dir}...", "INFO")
            cmd = ['git', 'clone']
            if branch:
                cmd.extend(['--branch', branch, '--single-branch'])
            cmd.extend([repo_url, dest_dir])
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError(result.stderr or result.stdout)
            self.log("Repository cloned successfully.", "SUCCESS")
        else:
            # Repo exists: try to fetch and checkout the requested branch
            self.log(f"Repository already exists at {dest_dir}, fetching updates...", "INFO")
            fetch = subprocess.run(['git', '-C', dest_dir, 'fetch'], capture_output=True, text=True)
            if fetch.returncode != 0:
                self.log(f"Git fetch failed: {fetch.stderr}", "WARNING")
            if branch:
                co = subprocess.run(['git', '-C', dest_dir, 'checkout', branch], capture_output=True, text=True)
                if co.returncode != 0:
                    # try to create local branch tracking origin/branch
                    self.log(f"Checkout failed, trying to create branch {branch}...", "INFO")
                    co2 = subprocess.run(['git', '-C', dest_dir, 'checkout', '-b', branch, f'origin/{branch}'], capture_output=True, text=True)
                    if co2.returncode != 0:
                        self.log(f"Failed to checkout branch: {co2.stderr}", "WARNING")

        # After cloning/pulling, check for requirements
        req_path = os.path.join(dest_dir, 'requirements.txt')
        if os.path.exists(req_path):
            self.log(f"Installing requirements from {req_path}...", "INFO")
            result = subprocess.run([pip_path, 'install', '-r', req_path], capture_output=True, text=True)
            if result.returncode == 0:
                self.log("Repository requirements installed.", "SUCCESS")
            else:
                raise RuntimeError(result.stderr or result.stdout)
        else:
            self.log("No requirements.txt found in repo; skipping pip install.", "INFO")
            
    def finish_build(self, success):
        self.progress.stop()
        self.is_building = False
        self.build_btn.config(state=tk.NORMAL)
        self.cancel_btn.config(state=tk.DISABLED)
        self.build_process = None
        
        if success:
            self.log("=" * 60, "SUCCESS")
            self.log("BUILD COMPLETED SUCCESSFULLY!", "SUCCESS")
            
            output_name = self.output_name.get()
            if self.create_single_exe.get():
                exe_path = os.path.join("dist", f"{output_name}.exe")
            else:
                exe_path = os.path.join("dist", output_name, f"{output_name}.exe")
                
            if os.path.exists(exe_path):
                size = os.path.getsize(exe_path)
                size_mb = size / (1024 * 1024)
                self.log(f"Executable created: {exe_path}", "SUCCESS")
                self.log(f"File size: {size_mb:.2f} MB", "SUCCESS")
                
                messagebox.showinfo(
                    "Build Complete",
                    f"Build completed successfully!\n\n"
                    f"Executable: {exe_path}\n"
                    f"Size: {size_mb:.2f} MB"
                )
        else:
            self.log("=" * 60, "ERROR")
            self.log("BUILD FAILED!", "ERROR")
            messagebox.showerror("Build Failed", "The build process failed. Check the log for details.")
            
    def open_output_folder(self):
        dist_path = os.path.join(os.getcwd(), "dist")
        if os.path.exists(dist_path):
            if os.name == 'nt':
                os.startfile(dist_path)
            elif os.name == 'posix':
                subprocess.run(['open', dist_path] if sys.platform == 'darwin' 
                             else ['xdg-open', dist_path])
        else:
            messagebox.showwarning("No Output", "Output folder doesn't exist yet.")
            
    def run(self):
        # Center window on screen
        self.root.eval('tk::PlaceWindow . center')
        self.root.mainloop()

if __name__ == "__main__":
    app = InstallerBuilderGUI()
    app.run()
