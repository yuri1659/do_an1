@echo off
:: run_build.bat - Safe build script
echo Chat Client Builder
echo ===================
echo.

:: Change to script directory
cd /d "%~dp0"

echo Current directory: %CD%
echo.

if not exist "Client.py" (
    echo ERROR: Client.py not found!
    echo Please place this batch file in the same directory as Client.py
    pause
    exit /b 1
)

echo Options:
echo 1. Build with GUI
echo 2. Build with simple console interface
echo 3. Exit
echo.

set /p choice="Choose option (1-3): "

if "%choice%"=="1" (
    echo Starting GUI builder...
    python build_installer_gui.py
) else if "%choice%"=="2" (
    echo Starting console builder...
    python build_safe.py
) else (
    exit
)

pause