STANDALONE CHAT CLIENT BUILDER
===============================

WHAT IS THIS?
-------------
This is a completely standalone executable that can build the Chat Client
without needing any external files. It contains:

1. The builder GUI interface
2. Client.py EMBEDDED inside the executable
3. All Python dependencies packaged

NO EXTERNAL FILES NEEDED!
- No need to have Client.py separately
- No need to install Python
- No need to install dependencies
- Everything is self-contained

HOW TO USE:
-----------
1. Double-click "Run_Standalone_Builder.bat"
2. OR run "dist\ChatClientBuilder.exe" directly
3. Click "Build Chat Client" in the GUI
4. Your ChatClient.exe will be created in the "dist" folder

WHAT HAPPENS WHEN YOU RUN IT:
-----------------------------
1. The builder extracts Client.py from its embedded resources
2. Creates a Python virtual environment (first time only)
3. Installs required packages (first time only)
4. Uses PyInstaller to build ChatClient.exe
5. Places the executable in the "dist" folder

TROUBLESHOOTING:
----------------
If the builder fails:
1. Run as Administrator
2. Check antivirus/firewall settings
3. Ensure you have internet connection (for first-time package downloads)
4. Make sure you have write permissions in the current directory

NOTE: The first build takes longer as it downloads and installs packages.
Subsequent builds will be much faster.
