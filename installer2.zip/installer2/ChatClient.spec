# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['Client.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['Crypto', 'Crypto.Cipher', 'Crypto.Cipher._raw_cbc', 'Crypto.Util', 'customtkinter', 'queue', 'tkinter'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='ChatClient',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
