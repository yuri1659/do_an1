@echo off
echo Starting ChatClient...
cd /d "D:\installer2\dist"
"dist\ChatClient.exe"
if errorlevel 1 pause
