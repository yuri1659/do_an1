@echo off
title STANDALONE CHAT CLIENT BUILDER
color 0A

echo ============================================
echo   STANDALONE CHAT CLIENT BUILDER
echo ============================================
echo.
echo This is a standalone builder that includes:
echo   � Complete GUI interface
echo   � Client.py EMBEDDED inside the executable
echo   � No external files needed!
echo.
echo Features:
echo   � Build ChatClient.exe with one click
echo   � No Python installation required
echo   � No Client.py file needed separately
echo   � Everything is self-contained
echo.
echo ============================================
echo.

REM Check if builder exists
if not exist "dist\ChatClientBuilder.exe" (
    echo ERROR: Builder executable not found!
    echo.
    echo Please run embed_and_build.py first to create the builder.
    echo.
    pause
    exit /b 1
)

echo Starting Standalone Chat Client Builder...
echo.
echo Note: The builder will extract Client.py from its embedded resources
echo and use it to build your chat client executable.
echo.
timeout /t 3 /nobreak >nul

REM Run the builder
start "" "dist\ChatClientBuilder.exe"

echo.
echo Builder started successfully!
echo Check your taskbar for the application window.
echo.
pause
